# Ahlashop Tracker

Bot Telegram qui envoie un résumé quotidien à 16h00 de tous les nouveaux produits et promos sur ahlashop.net.

## Setup GitHub Actions

1. Crée un repo GitHub (public ou privé)
2. Upload tous les fichiers dedans
3. Va dans Settings > Secrets > Actions et ajoute:
   - TELEGRAM_TOKEN = ton token BotFather
   - TELEGRAM_CHAT_ID = 7975203420
4. C'est tout ! Le bot s'exécute chaque jour à 16h00

## Test manuel
Va dans Actions > Daily Ahlashop Report > Run workflow
